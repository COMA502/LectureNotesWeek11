package edu.dmacc.coma502;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MainTest {
    @Test
    public void getNameShouldBeUppercase() {
        assertEquals("Greg", Main.getName());
    }

    @Test
    public void getCharAsIntShouldConvertLowercase() {
        assertEquals(1, Main.getCharAsInt('a'));
        assertEquals(26, Main.getCharAsInt('z'));
    }

    @Test
    public void getCharAsIntShouldConvertUppercase() {
        assertEquals(1, Main.getCharAsInt('A'));
        assertEquals(26, Main.getCharAsInt('Z'));
    }

//    @Test
//    public void getCharAsIntShouldThrowExceptionForNonLetter() {
//        try {
//            Main.getCharAsInt('!');
//            fail("Expected an IllegalArgumentException for non-letter");
//        } catch(IllegalArgumentException e) {
//        }
//    }

    @Test(expected = IllegalArgumentException.class)
    public void getCharAsIntShouldThrowExceptionForNonLetter() {
        Main.getCharAsInt('!');
    }
}
