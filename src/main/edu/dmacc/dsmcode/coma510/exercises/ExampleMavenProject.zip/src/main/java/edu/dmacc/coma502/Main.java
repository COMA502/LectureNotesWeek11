package edu.dmacc.coma502;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

    public static String getName() {
        return "Greg";
    }

    public static int getCharAsInt(char letter) {
        if(letter >= 'A' && letter <= 'Z') {
            return letter - 64;
        } else if(letter >= 'a' && letter <= 'z') {
            return letter - 96;
        } else {
            throw new IllegalArgumentException();
        }
    }
}
