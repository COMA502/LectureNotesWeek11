package edu.dmacc.coma502;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class MainWithAnswersTest {
    @Test
    public void shouldDoSomething() {
        assertEquals("Greg", MainWithAnswers.getMyName());
    }

    @Test
    public void getNumberFromLetterShouldConvertLowercaseLetters() {
        assertEquals(1, MainWithAnswers.getNumberFromLetter('a'));
        assertEquals(26, MainWithAnswers.getNumberFromLetter('z'));
    }

    @Test
    public void getNumberFromLetterShouldConvertUppercaseLetters() {
        assertEquals(1, MainWithAnswers.getNumberFromLetter('A'));
        assertEquals(26, MainWithAnswers.getNumberFromLetter('Z'));
    }

    @Test
    public void getNumberFromLetterShouldThrowExceptionForNonLetter1() {
        try {
            MainWithAnswers.getNumberFromLetter('1');
            fail("Expected IllegalArgumentException for '1'");
        } catch (IllegalArgumentException e1) {
        }
        try {
            MainWithAnswers.getNumberFromLetter('!');
            fail("Expected IllegalArgumentException for '!'");
        } catch (IllegalArgumentException e2) {
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void getNumberFromLetterShouldThrowExceptionForNonLetter2() {
        MainWithAnswers.getNumberFromLetter('1');
        MainWithAnswers.getNumberFromLetter('!');
    }
}
