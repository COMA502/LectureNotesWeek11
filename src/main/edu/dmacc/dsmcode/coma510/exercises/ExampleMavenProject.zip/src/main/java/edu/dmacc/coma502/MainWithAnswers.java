package edu.dmacc.coma502;

public class MainWithAnswers {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

    public static String getMyName() {
        return "Greg";
    }

    public static int getNumberFromLetter(char letter) {
        if(letter >= 96 && letter <= 122) {
            return letter - 96;
        } else if(letter >= 65 && letter <= 91) {
            return letter - 64;
        } else {
            throw new IllegalArgumentException(letter + " is not a letter");
        }
    }
}
